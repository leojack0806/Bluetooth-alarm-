package com.earalarm.app

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun EarAlarmTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

/** 알람이 울릴 때 잠금화면 위에 뜨는 화면 */
class RingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        setContent { EarAlarmTheme { RingScreen(onFinish = { finish() }) } }
    }
}

@Composable
fun RingScreen(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val info by AlarmService.ringing.collectAsState()
    var seen by remember { mutableStateOf(false) }
    var solved by remember { mutableStateOf(false) }
    var clock by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(info) {
        if (info != null) {
            seen = true
        } else if (seen) {
            onFinish()
        } else {
            delay(3000)
            if (AlarmService.ringing.value == null) onFinish()
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            clock = System.currentTimeMillis()
            delay(1000)
        }
    }
    BackHandler { /* 뒤로가기로 실수로 닫히지 않게 */ }

    fun send(action: String) {
        ctx.startService(AlarmService.actionIntent(ctx, action))
    }

    val i = info
    val needMission = i?.mission == true && !solved

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.primaryContainer) {
        Box(Modifier.fillMaxSize().systemBarsPadding(), contentAlignment = Alignment.Center) {
            Column(
                Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("⏰", fontSize = 64.sp)
                Text(
                    TimeUtil.formatClock(clock),
                    fontSize = 64.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                    i?.label?.ifBlank { "알람" } ?: "알람",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                    i?.modeText ?: "",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Spacer(Modifier.height(24.dp))

                if (needMission) MissionBox(onSolved = { solved = true })

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    FilledTonalButton(
                        onClick = { send(AlarmService.ACTION_SNOOZE) },
                        modifier = Modifier.weight(1f).height(72.dp),
                    ) { Text("💤 ${i?.snoozeMinutes ?: 5}분 뒤", fontSize = 20.sp) }
                    Button(
                        onClick = { send(AlarmService.ACTION_DISMISS) },
                        enabled = !needMission,
                        modifier = Modifier.weight(1f).height(72.dp),
                    ) { Text("끄기", fontSize = 20.sp) }
                }
            }
        }
    }
}

/** 잠 깨기 미션: 곱셈 문제 */
@Composable
fun MissionBox(onSolved: () -> Unit) {
    val a = remember { Random.nextInt(3, 10) }
    val b = remember { Random.nextInt(12, 30) }
    var answer by remember { mutableStateOf("") }
    Card(Modifier.fillMaxWidth()) {
        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("끄려면 문제를 풀어 주세요", style = MaterialTheme.typography.titleMedium)
            Text("$a × $b = ?", style = MaterialTheme.typography.headlineMedium)
            OutlinedTextField(
                value = answer,
                onValueChange = { v ->
                    answer = v.filter { it.isDigit() }.take(4)
                    if (answer.toIntOrNull() == a * b) onSolved()
                },
                singleLine = true,
                label = { Text("정답") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        }
    }
}
