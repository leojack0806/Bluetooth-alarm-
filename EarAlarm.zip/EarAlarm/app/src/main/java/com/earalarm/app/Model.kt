package com.earalarm.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** 알람 하나의 설정 */
data class Alarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    /** Calendar.SUNDAY(1) ~ Calendar.SATURDAY(7). 비어 있으면 한 번만 울림 */
    val days: Set<Int> = emptySet(),
    val label: String = "",
    val enabled: Boolean = true,
    /** 볼륨 (%) */
    val volume: Int = 60,
    /** null 이면 기본 알람음 */
    val soundUri: String? = null,
    val soundName: String = "기본 알람음",
    /** 점점 커지는 시간(초). 0 이면 바로 최대 볼륨 */
    val fadeSeconds: Int = 30,
    val vibrate: Boolean = false,
    /** 수학 문제를 풀어야 끌 수 있음 */
    val mission: Boolean = false,
    /** 빠른 알람(낮잠) — 끄면 목록에서 자동 삭제 */
    val temporary: Boolean = false,
    /** 스누즈로 다시 울릴 시각 (0 = 없음) */
    val snoozeUntil: Long = 0L,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("hour", hour)
        put("minute", minute)
        put("days", JSONArray(days.toList()))
        put("label", label)
        put("enabled", enabled)
        put("volume", volume)
        put("soundUri", soundUri ?: JSONObject.NULL)
        put("soundName", soundName)
        put("fadeSeconds", fadeSeconds)
        put("vibrate", vibrate)
        put("mission", mission)
        put("temporary", temporary)
        put("snoozeUntil", snoozeUntil)
    }

    companion object {
        fun fromJson(o: JSONObject): Alarm {
            val arr = o.optJSONArray("days")
            val days = mutableSetOf<Int>()
            if (arr != null) for (i in 0 until arr.length()) days.add(arr.getInt(i))
            return Alarm(
                id = o.getInt("id"),
                hour = o.optInt("hour", 7),
                minute = o.optInt("minute", 0),
                days = days,
                label = o.optString("label", ""),
                enabled = o.optBoolean("enabled", true),
                volume = o.optInt("volume", 60),
                soundUri = if (o.isNull("soundUri")) null else o.optString("soundUri"),
                soundName = o.optString("soundName", "기본 알람음"),
                fadeSeconds = o.optInt("fadeSeconds", 30),
                vibrate = o.optBoolean("vibrate", false),
                mission = o.optBoolean("mission", false),
                temporary = o.optBoolean("temporary", false),
                snoozeUntil = o.optLong("snoozeUntil", 0L),
            )
        }
    }
}

/** 이어폰이 없을 때 어떻게 할지 */
enum class Fallback(val label: String, val desc: String) {
    VIBRATE("진동만", "소리 없이 진동으로 깨워요"),
    SILENT("화면 표시만 (무음)", "소리·진동 없이 알람 화면만 띄워요"),
    SPEAKER("스피커로 재생", "이어폰이 없으면 일반 알람처럼 스피커로 울려요"),
}

/** 앱 전체 설정 */
data class AppSettings(
    val fallback: Fallback = Fallback.VIBRATE,
    val includeBluetooth: Boolean = true,
    val resumeOnReconnect: Boolean = true,
    val forceVolume: Boolean = true,
    val snoozeMinutes: Int = 5,
    val autoStopMinutes: Int = 10,
)

/** 지금 울리고 있는 알람 정보 (울림 화면에서 사용) */
data class RingInfo(
    val alarmId: Int,
    val label: String,
    val modeText: String,
    val mission: Boolean,
    val snoozeMinutes: Int,
)

object AlarmStore {
    private const val PREFS = "ear_alarm"
    private const val KEY_ALARMS = "alarms"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun load(ctx: Context): List<Alarm> {
        val raw = prefs(ctx).getString(KEY_ALARMS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length())
                .map { Alarm.fromJson(arr.getJSONObject(it)) }
                .sortedWith(compareBy({ it.hour }, { it.minute }, { it.id }))
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    private fun saveAll(ctx: Context, list: List<Alarm>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString(KEY_ALARMS, arr.toString()).commit()
    }

    fun get(ctx: Context, id: Int): Alarm? = load(ctx).firstOrNull { it.id == id }

    @Synchronized
    fun upsert(ctx: Context, alarm: Alarm) {
        saveAll(ctx, load(ctx).filter { it.id != alarm.id } + alarm)
    }

    @Synchronized
    fun delete(ctx: Context, id: Int) {
        saveAll(ctx, load(ctx).filter { it.id != id })
    }

    @Synchronized
    fun newId(ctx: Context): Int {
        val p = prefs(ctx)
        val next = maxOf(p.getInt("next_id", 1), (load(ctx).maxOfOrNull { it.id } ?: 0) + 1)
        p.edit().putInt("next_id", next + 1).commit()
        return next
    }

    fun loadSettings(ctx: Context): AppSettings {
        val p = prefs(ctx)
        val d = AppSettings()
        return AppSettings(
            fallback = runCatching { Fallback.valueOf(p.getString("fallback", d.fallback.name)!!) }
                .getOrDefault(d.fallback),
            includeBluetooth = p.getBoolean("includeBluetooth", d.includeBluetooth),
            resumeOnReconnect = p.getBoolean("resumeOnReconnect", d.resumeOnReconnect),
            forceVolume = p.getBoolean("forceVolume", d.forceVolume),
            snoozeMinutes = p.getInt("snoozeMinutes", d.snoozeMinutes),
            autoStopMinutes = p.getInt("autoStopMinutes", d.autoStopMinutes),
        )
    }

    fun saveSettings(ctx: Context, s: AppSettings) {
        prefs(ctx).edit()
            .putString("fallback", s.fallback.name)
            .putBoolean("includeBluetooth", s.includeBluetooth)
            .putBoolean("resumeOnReconnect", s.resumeOnReconnect)
            .putBoolean("forceVolume", s.forceVolume)
            .putInt("snoozeMinutes", s.snoozeMinutes)
            .putInt("autoStopMinutes", s.autoStopMinutes)
            .commit()
    }
}
