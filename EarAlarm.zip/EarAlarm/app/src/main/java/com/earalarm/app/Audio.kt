package com.earalarm.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings

/** 연결된 이어폰(유선 / USB-C / 블루투스) 찾기 */
object Earphones {
    private val WIRED = intArrayOf(
        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_USB_HEADSET,
    )

    private fun bluetoothTypes(): IntArray =
        if (Build.VERSION.SDK_INT >= 31) {
            intArrayOf(
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                AudioDeviceInfo.TYPE_BLE_HEADSET,
                AudioDeviceInfo.TYPE_HEARING_AID,
            )
        } else {
            intArrayOf(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_HEARING_AID)
        }

    fun find(ctx: Context, includeBluetooth: Boolean): AudioDeviceInfo? {
        val am = ctx.getSystemService(AudioManager::class.java) ?: return null
        val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        outs.firstOrNull { it.type in WIRED }?.let { return it }
        if (includeBluetooth) {
            val bt = bluetoothTypes()
            outs.firstOrNull { it.type in bt }?.let { return it }
        }
        return null
    }

    fun describe(d: AudioDeviceInfo): String {
        val kind = when (d.type) {
            AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "유선 이어폰"
            AudioDeviceInfo.TYPE_USB_HEADSET -> "USB-C 이어폰"
            else -> "블루투스 이어폰"
        }
        val name = d.productName?.toString()?.trim().orEmpty()
        return if (kind == "블루투스 이어폰" && name.isNotEmpty()) "$kind · $name" else kind
    }
}

object Sounds {
    /** 시도할 소리 목록: 선택한 소리 → 기본 알람음 → 벨소리 → 알림음 */
    private fun candidates(ctx: Context, uri: String?): List<Uri> = listOfNotNull(
        uri?.let { runCatching { Uri.parse(it) }.getOrNull() },
        runCatching { RingtoneManager.getActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_ALARM) }.getOrNull(),
        Settings.System.DEFAULT_ALARM_ALERT_URI,
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
    ).distinct()

    /**
     * 준비된(아직 재생 전) 반복 재생 플레이어를 만든다.
     * device 를 주면 그 출력 장치(이어폰)로만 재생하도록 지정한다.
     *
     * 핵심: USAGE_ALARM 으로 재생하면 안드로이드가 이어폰과 스피커에서 동시에 울리게 하므로,
     * 미디어(USAGE_MEDIA)로 재생하고 출력 장치를 이어폰으로 고정한다.
     */
    fun createPlayer(ctx: Context, uri: String?, device: AudioDeviceInfo?): MediaPlayer? {
        for (u in candidates(ctx, uri)) {
            val mp = MediaPlayer()
            try {
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build(),
                )
                mp.setDataSource(ctx, u)
                mp.isLooping = true
                if (device != null) mp.setPreferredDevice(device)
                mp.prepare()
                return mp
            } catch (e: Exception) {
                mp.release()
            }
        }
        return null
    }

    fun titleOf(ctx: Context, uri: Uri, fromFile: Boolean): String {
        if (fromFile) {
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c ->
                        if (c.moveToFirst()) {
                            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (i >= 0) {
                                val n = c.getString(i)
                                if (!n.isNullOrBlank()) return n.substringBeforeLast('.')
                            }
                        }
                    }
            } catch (_: Exception) {
            }
        }
        return try {
            RingtoneManager.getRingtone(ctx, uri)?.getTitle(ctx) ?: "선택한 소리"
        } catch (_: Exception) {
            "선택한 소리"
        }
    }
}

/** 편집 화면의 '미리듣기' — 이어폰으로만 재생 */
object SoundPreview {
    private var player: MediaPlayer? = null

    /** 이어폰이 없으면 재생하지 않고 false */
    fun play(ctx: Context, uri: String?, includeBluetooth: Boolean, volumePercent: Int): Boolean {
        stop()
        val ear = Earphones.find(ctx, includeBluetooth) ?: return false
        val p = Sounds.createPlayer(ctx, uri, ear) ?: return false
        val v = (volumePercent / 100f).coerceIn(0.05f, 1f)
        p.setVolume(v, v)
        p.start()
        player = p
        return true
    }

    fun stop() {
        player?.let {
            try {
                it.setVolume(0f, 0f)
                if (it.isPlaying) it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        player = null
    }
}

object Notifications {
    const val CHANNEL_RING = "ring"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_RING) != null) return
        val ch = NotificationChannel(CHANNEL_RING, "알람", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "울리고 있는 알람"
            setSound(null, null) // 소리는 앱이 직접 이어폰으로 재생
            enableVibration(false) // 진동도 앱이 직접 제어
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(ch)
    }
}
