@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.earalarm.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.delay
import java.util.Calendar
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifications.ensureChannel(this)
        AlarmScheduler.scheduleAll(this)
        enableEdgeToEdge()
        setContent { EarAlarmTheme { MainScreen(resumeTick.intValue) } }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }

    override fun onPause() {
        super.onPause()
        SoundPreview.stop()
    }
}

private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

// ───────────────────────── 권한 상태 ─────────────────────────

data class PermissionState(
    val notifications: Boolean,
    val exactAlarm: Boolean,
    val fullScreen: Boolean,
    val battery: Boolean,
) {
    val allGood get() = notifications && exactAlarm && fullScreen && battery

    companion object {
        fun check(ctx: Context): PermissionState {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val notif = nm.areNotificationsEnabled() && (
                Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
                    ctx, Manifest.permission.POST_NOTIFICATIONS,
                ) == PackageManager.PERMISSION_GRANTED
                )
            val exact = Build.VERSION.SDK_INT < 31 ||
                ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
            val full = Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent()
            val battery = ctx.getSystemService(PowerManager::class.java)
                .isIgnoringBatteryOptimizations(ctx.packageName)
            return PermissionState(notif, exact, full, battery)
        }
    }
}

private fun openSettings(ctx: Context, action: String, withPackageUri: Boolean = true) {
    val pkgUri = Uri.parse("package:${ctx.packageName}")
    val intent = Intent(action).apply {
        if (withPackageUri) data = pkgUri
        putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
    }
    try {
        ctx.startActivity(intent)
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri))
        } catch (_: Exception) {
        }
    }
}

// ───────────────────────── 이어폰 연결 상태 (실시간) ─────────────────────────

@Composable
fun rememberEarphone(includeBluetooth: Boolean): State<AudioDeviceInfo?> {
    val ctx = LocalContext.current
    val state = remember { mutableStateOf<AudioDeviceInfo?>(null) }
    DisposableEffect(includeBluetooth) {
        val am = ctx.getSystemService(AudioManager::class.java)
        val cb = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
                state.value = Earphones.find(ctx, includeBluetooth)
            }

            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                state.value = Earphones.find(ctx, includeBluetooth)
            }
        }
        state.value = Earphones.find(ctx, includeBluetooth)
        am.registerAudioDeviceCallback(cb, Handler(Looper.getMainLooper()))
        onDispose { am.unregisterAudioDeviceCallback(cb) }
    }
    return state
}

// ───────────────────────── 메인 화면 ─────────────────────────

@Composable
fun MainScreen(resumeTick: Int) {
    val ctx = LocalContext.current
    var alarms by remember { mutableStateOf(AlarmStore.load(ctx)) }
    var settings by remember { mutableStateOf(AlarmStore.loadSettings(ctx)) }
    var perms by remember { mutableStateOf(PermissionState.check(ctx)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var editing by remember { mutableStateOf<Alarm?>(null) }
    var deleting by remember { mutableStateOf<Alarm?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    val ear by rememberEarphone(settings.includeBluetooth)
    val ring by AlarmService.ringing.collectAsState()

    fun refresh() {
        alarms = AlarmStore.load(ctx)
        perms = PermissionState.check(ctx)
        now = System.currentTimeMillis()
    }

    fun commit(a: Alarm, announce: Boolean = true) {
        AlarmStore.upsert(ctx, a)
        AlarmScheduler.schedule(ctx, a)
        refresh()
        if (announce && a.enabled) {
            val t = TimeUtil.nextTrigger(a)
            toast(ctx, "${TimeUtil.relative(t - System.currentTimeMillis())} 후에 울려요")
        }
    }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { refresh() }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !perms.notifications) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    LaunchedEffect(resumeTick) { refresh() }
    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000)
            now = System.currentTimeMillis()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🎧 이어폰 알람") },
                actions = {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Filled.Settings, contentDescription = "설정")
                    }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                text = { Text("알람 추가") },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                onClick = {
                    editing = Alarm(id = AlarmStore.newId(ctx), hour = 7, minute = 0)
                },
            )
        },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.TopCenter) {
            LazyColumn(
                Modifier.fillMaxHeight().widthIn(max = 720.dp).fillMaxWidth(),
                contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (ring != null) item {
                    RingingBanner(onOpen = {
                        ctx.startActivity(
                            Intent(ctx, RingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    })
                }
                item { EarphoneCard(ear, settings) }
                if (!perms.allGood) item {
                    PermissionCard(perms, onNotif = {
                        if (Build.VERSION.SDK_INT >= 33) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        openSettings(ctx, Settings.ACTION_APP_NOTIFICATION_SETTINGS, withPackageUri = false)
                    })
                }
                item { NextAlarmCard(alarms, now) }
                item {
                    QuickAlarmCard(onPick = { m ->
                        val c = Calendar.getInstance().apply { add(Calendar.MINUTE, m) }
                        commit(
                            Alarm(
                                id = AlarmStore.newId(ctx),
                                hour = c.get(Calendar.HOUR_OF_DAY),
                                minute = c.get(Calendar.MINUTE),
                                label = "빠른 알람 ${m}분",
                                temporary = true,
                                fadeSeconds = 10,
                            ),
                        )
                    })
                }
                if (alarms.isEmpty()) item {
                    Text(
                        "아직 알람이 없어요. 오른쪽 아래 ‘알람 추가’를 눌러 보세요.",
                        modifier = Modifier.padding(24.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                items(alarms, key = { it.id }) { a ->
                    AlarmCard(
                        a = a,
                        now = now,
                        onClick = { editing = a },
                        onToggle = { on -> commit(a.copy(enabled = on, snoozeUntil = 0L)) },
                        onDelete = { deleting = a },
                        onCancelSnooze = { commit(a.copy(snoozeUntil = 0L), announce = false) },
                    )
                }
            }
        }
    }

    editing?.let { a ->
        AlarmEditor(
            initial = a,
            isNew = alarms.none { it.id == a.id },
            includeBluetooth = settings.includeBluetooth,
            onDismiss = {
                SoundPreview.stop()
                editing = null
            },
            onSave = {
                SoundPreview.stop()
                editing = null
                commit(it)
            },
        )
    }

    deleting?.let { a ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("알람 삭제") },
            text = { Text("${TimeUtil.formatTime(a.hour, a.minute)} ${a.label} 알람을 삭제할까요?") },
            confirmButton = {
                TextButton(onClick = {
                    AlarmScheduler.cancel(ctx, a.id)
                    AlarmStore.delete(ctx, a.id)
                    deleting = null
                    refresh()
                }) { Text("삭제") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("취소") } },
        )
    }

    if (showSettings) {
        SettingsDialog(
            initial = settings,
            onDismiss = { showSettings = false },
            onSave = {
                AlarmStore.saveSettings(ctx, it)
                settings = it
                showSettings = false
            },
        )
    }
}

// ───────────────────────── 카드들 ─────────────────────────

@Composable
fun RingingBanner(onOpen: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("⏰ 알람이 울리는 중이에요", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            Button(onClick = onOpen) { Text("열기") }
        }
    }
}

@Composable
fun EarphoneCard(ear: AudioDeviceInfo?, settings: AppSettings) {
    val connected = ear != null
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (connected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(if (connected) "🎧" else "🔇", fontSize = 36.sp)
            Column {
                Text(
                    if (connected) "이어폰 연결됨" else "이어폰 연결 안 됨",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    if (ear != null) "${Earphones.describe(ear)} · 알람이 이어폰으로만 울려요"
                    else "지금 알람이 울리면 → ${settings.fallback.label}",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
fun PermissionCard(p: PermissionState, onNotif: () -> Unit) {
    val ctx = LocalContext.current
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "⚠️ 알람이 확실히 울리려면 아래 설정이 필요해요",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
            )
            if (!p.notifications) PermRow("알림 허용", "알람 화면과 끄기 버튼을 보여 줘요", onNotif)
            if (!p.exactAlarm && Build.VERSION.SDK_INT >= 31) PermRow("정확한 알람 허용", "정해진 시각에 정확히 울려요") {
                openSettings(ctx, Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
            }
            if (!p.fullScreen && Build.VERSION.SDK_INT >= 34) PermRow("전체 화면 알림 허용", "잠금화면 위에 알람 화면을 띄워요") {
                openSettings(ctx, Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
            }
            if (!p.battery) PermRow("배터리 최적화 제외", "삼성 절전 기능이 알람을 막지 않게 해요") {
                openSettings(ctx, Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            }
        }
    }
}

@Composable
fun PermRow(title: String, desc: String, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall)
        }
        FilledTonalButton(onClick = onClick) { Text("설정") }
    }
}

@Composable
fun NextAlarmCard(alarms: List<Alarm>, now: Long) {
    val next = alarms.flatMap {
        listOfNotNull(
            if (it.enabled) TimeUtil.nextTrigger(it, now) else null,
            it.snoozeUntil.takeIf { s -> s > now },
        )
    }.minOrNull()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("다음 알람", style = MaterialTheme.typography.labelLarge)
            if (next == null) {
                Text("켜진 알람이 없어요", style = MaterialTheme.typography.titleMedium)
            } else {
                Text(TimeUtil.formatDateTime(next), style = MaterialTheme.typography.titleLarge)
                Text(
                    "${TimeUtil.relative(next - now)} 후",
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}

@Composable
fun QuickAlarmCard(onPick: (Int) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("⚡ 빠른 알람 (낮잠·타이머)", style = MaterialTheme.typography.titleSmall)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(5, 10, 15, 20, 30, 60, 90).forEach { m ->
                    FilledTonalButton(onClick = { onPick(m) }) { Text("${m}분") }
                }
            }
        }
    }
}

@Composable
fun AlarmCard(
    a: Alarm,
    now: Long,
    onClick: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit,
    onCancelSnooze: () -> Unit,
) {
    val dim = if (a.enabled) 1f else 0.45f
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    TimeUtil.formatTime(a.hour, a.minute),
                    fontSize = 34.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = dim),
                )
                Text(
                    listOf(a.label, TimeUtil.daysText(a.days)).filter { it.isNotBlank() }.joinToString(" · "),
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = dim),
                )
                val tags = buildList {
                    add("🔊 ${a.volume}%")
                    if (a.fadeSeconds > 0) add("📈 ${a.fadeSeconds}초")
                    if (a.vibrate) add("📳 진동")
                    if (a.mission) add("🧮 미션")
                    add("🎵 ${a.soundName}")
                }
                Text(
                    tags.joinToString("  "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = dim),
                    maxLines = 1,
                )
                if (a.snoozeUntil > now) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "💤 ${TimeUtil.formatClock(a.snoozeUntil)}에 다시 울림",
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        TextButton(onClick = onCancelSnooze) { Text("취소") }
                    }
                }
            }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "삭제") }
            Switch(checked = a.enabled, onCheckedChange = onToggle)
        }
    }
}

// ───────────────────────── 알람 편집 ─────────────────────────

@Composable
fun AlarmEditor(
    initial: Alarm,
    isNew: Boolean,
    includeBluetooth: Boolean,
    onDismiss: () -> Unit,
    onSave: (Alarm) -> Unit,
) {
    val ctx = LocalContext.current
    val timeState = rememberTimePickerState(
        initialHour = initial.hour, initialMinute = initial.minute, is24Hour = false,
    )
    var label by remember { mutableStateOf(initial.label) }
    var days by remember { mutableStateOf(initial.days) }
    var volume by remember { mutableFloatStateOf(initial.volume.toFloat()) }
    var fade by remember { mutableFloatStateOf(initial.fadeSeconds.toFloat()) }
    var vibrate by remember { mutableStateOf(initial.vibrate) }
    var mission by remember { mutableStateOf(initial.mission) }
    var soundUri by remember { mutableStateOf(initial.soundUri) }
    var soundName by remember { mutableStateOf(initial.soundName) }
    var previewing by remember { mutableStateOf(false) }

    val ringtoneLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val uri = res.data?.let {
                IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            }
            if (uri != null) {
                soundUri = uri.toString()
                soundName = Sounds.titleOf(ctx, uri, fromFile = false)
            }
        }
    }
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            soundUri = uri.toString()
            soundName = Sounds.titleOf(ctx, uri, fromFile = true)
        }
    }

    LaunchedEffect(previewing) {
        if (previewing) {
            delay(8000)
            SoundPreview.stop()
            previewing = false
        }
    }
    DisposableEffect(Unit) { onDispose { SoundPreview.stop() } }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth(0.94f).widthIn(max = 640.dp).fillMaxHeight(0.92f),
        ) {
            Column {
                Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Text(if (isNew) "새 알람" else "알람 편집", style = MaterialTheme.typography.titleLarge)
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        TimePicker(state = timeState)
                    }
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = it.take(30) },
                        label = { Text("이름 (선택)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )

                    SectionTitle("반복: ${TimeUtil.daysText(days)}")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TimeUtil.dayOrder.forEach { (d, name) ->
                            FilterChip(
                                selected = d in days,
                                onClick = { days = if (d in days) days - d else days + d },
                                label = { Text(name) },
                            )
                        }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick = { days = TimeUtil.EVERYDAY }) { Text("매일") }
                        TextButton(onClick = { days = TimeUtil.WEEKDAYS }) { Text("평일") }
                        TextButton(onClick = { days = TimeUtil.WEEKEND }) { Text("주말") }
                        TextButton(onClick = { days = emptySet() }) { Text("한 번만") }
                    }

                    HorizontalDivider()
                    SectionTitle("🔊 볼륨 ${volume.roundToInt()}%")
                    Slider(value = volume, onValueChange = { volume = it }, valueRange = 5f..100f)

                    SectionTitle(
                        if (fade < 1f) "📈 점점 커지기: 끔"
                        else "📈 점점 커지기: ${fade.roundToInt()}초 동안",
                    )
                    Slider(value = fade, onValueChange = { fade = it }, valueRange = 0f..120f, steps = 11)

                    HorizontalDivider()
                    SectionTitle("🎵 알람음: $soundName")
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedButton(onClick = {
                            soundUri = null
                            soundName = "기본 알람음"
                        }) { Text("기본 알람음") }
                        OutlinedButton(onClick = {
                            val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "알람음 선택")
                            soundUri?.let {
                                i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it))
                            }
                            try {
                                ringtoneLauncher.launch(i)
                            } catch (_: Exception) {
                                toast(ctx, "소리 선택 화면을 열 수 없어요")
                            }
                        }) { Text("시스템 소리") }
                        OutlinedButton(onClick = {
                            try {
                                fileLauncher.launch(arrayOf("audio/*"))
                            } catch (_: Exception) {
                                toast(ctx, "파일 선택 화면을 열 수 없어요")
                            }
                        }) { Text("내 음악 파일") }
                        Button(onClick = {
                            if (previewing) {
                                SoundPreview.stop()
                                previewing = false
                            } else if (SoundPreview.play(ctx, soundUri, includeBluetooth, volume.roundToInt())) {
                                previewing = true
                            } else {
                                toast(ctx, "이어폰을 연결해 주세요. 미리듣기도 이어폰으로만 재생돼요.")
                            }
                        }) { Text(if (previewing) "■ 정지" else "🎧 미리듣기") }
                    }

                    HorizontalDivider()
                    SwitchRow("📳 진동도 함께", vibrate, "이어폰과 함께 탭도 진동해요") { vibrate = it }
                    SwitchRow("🧮 문제를 풀어야 끄기", mission, "곱셈 문제를 맞혀야 끌 수 있어요 (스누즈는 가능)") {
                        mission = it
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.End,
                ) {
                    TextButton(onClick = onDismiss) { Text("취소") }
                    Button(onClick = {
                        onSave(
                            initial.copy(
                                hour = timeState.hour,
                                minute = timeState.minute,
                                label = label.trim(),
                                days = days,
                                volume = volume.roundToInt(),
                                fadeSeconds = fade.roundToInt(),
                                vibrate = vibrate,
                                mission = mission,
                                soundUri = soundUri,
                                soundName = soundName,
                                enabled = true,
                                snoozeUntil = 0L,
                            ),
                        )
                    }) { Text("저장") }
                }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
}

@Composable
fun SwitchRow(title: String, checked: Boolean, sub: String? = null, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (sub != null) {
                Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ───────────────────────── 설정 ─────────────────────────

@Composable
fun SettingsDialog(initial: AppSettings, onDismiss: () -> Unit, onSave: (AppSettings) -> Unit) {
    var s by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("설정") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                SectionTitle("이어폰이 없을 때")
                Fallback.entries.forEach { f ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .selectable(selected = s.fallback == f, onClick = { s = s.copy(fallback = f) })
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = s.fallback == f, onClick = null)
                        Column(Modifier.padding(start = 8.dp)) {
                            Text(f.label)
                            Text(
                                f.desc,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                HorizontalDivider()
                SwitchRow("블루투스 이어폰도 사용", s.includeBluetooth, "끄면 유선·USB-C 이어폰만 인정해요") {
                    s = s.copy(includeBluetooth = it)
                }
                SwitchRow("다시 연결하면 이어폰으로 재생", s.resumeOnReconnect, "알람 중 이어폰을 다시 꽂으면 소리가 다시 나요") {
                    s = s.copy(resumeOnReconnect = it)
                }
                SwitchRow("알람 볼륨 자동 적용", s.forceVolume, "울릴 때 미디어 볼륨을 알람 볼륨으로 맞추고, 끝나면 되돌려요") {
                    s = s.copy(forceVolume = it)
                }
                HorizontalDivider()
                SectionTitle("💤 스누즈: ${s.snoozeMinutes}분")
                Slider(
                    value = s.snoozeMinutes.toFloat(),
                    onValueChange = { s = s.copy(snoozeMinutes = it.roundToInt()) },
                    valueRange = 1f..30f,
                    steps = 28,
                )
                SectionTitle("⏹ 자동 종료: ${s.autoStopMinutes}분 동안 안 끄면")
                Slider(
                    value = s.autoStopMinutes.toFloat(),
                    onValueChange = { s = s.copy(autoStopMinutes = it.roundToInt()) },
                    valueRange = 1f..60f,
                    steps = 58,
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(s) }) { Text("저장") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } },
    )
}
