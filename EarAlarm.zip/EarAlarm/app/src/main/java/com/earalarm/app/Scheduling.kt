package com.earalarm.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object TimeUtil {
    private val ORDER = listOf(
        Calendar.MONDAY to "월", Calendar.TUESDAY to "화", Calendar.WEDNESDAY to "수",
        Calendar.THURSDAY to "목", Calendar.FRIDAY to "금", Calendar.SATURDAY to "토",
        Calendar.SUNDAY to "일",
    )
    val dayOrder: List<Pair<Int, String>> get() = ORDER
    val WEEKDAYS = setOf(
        Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY,
    )
    val WEEKEND = setOf(Calendar.SATURDAY, Calendar.SUNDAY)
    val EVERYDAY = WEEKDAYS + WEEKEND

    /** from 이후 이 알람이 처음 울릴 시각 */
    fun nextTrigger(a: Alarm, from: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = from
            set(Calendar.HOUR_OF_DAY, a.hour)
            set(Calendar.MINUTE, a.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (a.days.isEmpty()) {
            if (c.timeInMillis <= from) c.add(Calendar.DAY_OF_YEAR, 1)
            return c.timeInMillis
        }
        repeat(8) {
            if (c.get(Calendar.DAY_OF_WEEK) in a.days && c.timeInMillis > from) return c.timeInMillis
            c.add(Calendar.DAY_OF_YEAR, 1)
            c.set(Calendar.HOUR_OF_DAY, a.hour)
            c.set(Calendar.MINUTE, a.minute)
        }
        return c.timeInMillis
    }

    fun daysText(days: Set<Int>): String = when {
        days.isEmpty() -> "한 번"
        days == EVERYDAY -> "매일"
        days == WEEKDAYS -> "평일"
        days == WEEKEND -> "주말"
        else -> ORDER.filter { it.first in days }.joinToString(" ") { it.second }
    }

    fun formatTime(h: Int, m: Int): String {
        val ampm = if (h < 12) "오전" else "오후"
        val h12 = if (h % 12 == 0) 12 else h % 12
        return String.format(Locale.KOREAN, "%s %d:%02d", ampm, h12, m)
    }

    fun formatClock(ms: Long): String = SimpleDateFormat("a h:mm", Locale.KOREAN).format(Date(ms))

    fun formatDateTime(ms: Long): String =
        SimpleDateFormat("M월 d일 (E) a h:mm", Locale.KOREAN).format(Date(ms))

    /** "3시간 5분" 같은 남은 시간 */
    fun relative(ms: Long): String {
        val totalMin = ((ms + 59_999) / 60_000).coerceAtLeast(0)
        val d = totalMin / 1440
        val h = (totalMin % 1440) / 60
        val m = totalMin % 60
        val parts = buildList {
            if (d > 0) add("${d}일")
            if (h > 0) add("${h}시간")
            if (m > 0) add("${m}분")
        }
        return if (parts.isEmpty()) "1분 미만" else parts.joinToString(" ")
    }
}

object AlarmScheduler {
    const val ACTION_FIRE = "com.earalarm.app.FIRE"
    const val EXTRA_SNOOZE = "snooze"

    fun scheduleAll(ctx: Context) {
        AlarmStore.load(ctx).forEach { schedule(ctx, it) }
    }

    /** 알람의 다음 울림(및 스누즈)을 시스템에 등록. 꺼져 있으면 취소만 함 */
    fun schedule(ctx: Context, a: Alarm, from: Long = System.currentTimeMillis()) {
        cancel(ctx, a.id)
        if (a.enabled) set(ctx, a.id, false, TimeUtil.nextTrigger(a, from))
        if (a.snoozeUntil > System.currentTimeMillis()) set(ctx, a.id, true, a.snoozeUntil)
    }

    fun cancel(ctx: Context, id: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(operation(ctx, id, false))
        am.cancel(operation(ctx, id, true))
    }

    private fun operation(ctx: Context, id: Int, snooze: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .setAction(ACTION_FIRE)
            .putExtra(AlarmService.EXTRA_ID, id)
            .putExtra(EXTRA_SNOOZE, snooze)
        val code = id * 2 + (if (snooze) 1 else 0)
        return PendingIntent.getBroadcast(
            ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }

    private fun set(ctx: Context, id: Int, snooze: Boolean, time: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val op = operation(ctx, id, snooze)
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        try {
            // 알람 시계용 API: 절전(Doze) 중에도 정확히 울리고, 상태바에 알람 아이콘 표시
            am.setAlarmClock(AlarmManager.AlarmClockInfo(time, show), op)
        } catch (e: SecurityException) {
            try {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, op)
            } catch (_: Exception) {
            }
        }
    }
}

/** 알람 시각이 되면 호출됨 → 울림 서비스 시작 */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(AlarmService.EXTRA_ID, -1)
        val snooze = intent.getBooleanExtra(AlarmScheduler.EXTRA_SNOOZE, false)
        val a = AlarmStore.get(context, id) ?: return
        if (!snooze && !a.enabled) return
        if (snooze && a.snoozeUntil == 0L) return // 스누즈가 취소된 경우

        var updated = a
        if (snooze) updated = updated.copy(snoozeUntil = 0L)
        else if (a.days.isEmpty()) updated = updated.copy(enabled = false) // 한 번 알람은 끔
        if (updated != a) AlarmStore.upsert(context, updated)
        // 반복 알람은 다음 날짜로 다시 예약
        AlarmScheduler.schedule(context, updated, System.currentTimeMillis() + 60_000)

        ContextCompat.startForegroundService(context, AlarmService.startIntent(context, id))
    }
}

/** 재부팅·시간 변경·앱 업데이트 후 알람 다시 등록 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.scheduleAll(context)
    }
}
