package com.earalarm.app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.roundToInt

/**
 * 알람이 울리는 동안 동작하는 서비스.
 * - 이어폰이 있으면 이어폰으로만 재생
 * - 알람 중 이어폰이 빠지면 즉시 소리를 끄고 설정한 대체 동작(진동 등)으로 전환
 * - 다시 꽂으면 이어폰으로 재생 재개
 */
class AlarmService : Service() {

    enum class Mode { EARPHONE, SPEAKER, VIBRATE, SILENT }

    companion object {
        const val ACTION_START = "com.earalarm.app.START"
        const val ACTION_SNOOZE = "com.earalarm.app.SNOOZE"
        const val ACTION_DISMISS = "com.earalarm.app.DISMISS"
        const val EXTRA_ID = "alarm_id"
        private const val NOTIF_ID = 4201

        /** 지금 울리는 알람 (없으면 null) */
        val ringing = MutableStateFlow<RingInfo?>(null)

        fun startIntent(ctx: Context, id: Int): Intent =
            Intent(ctx, AlarmService::class.java).setAction(ACTION_START).putExtra(EXTRA_ID, id)

        fun actionIntent(ctx: Context, action: String): Intent =
            Intent(ctx, AlarmService::class.java).setAction(action)
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var audio: AudioManager
    private var player: MediaPlayer? = null
    private var playerMax = 1f
    private var fadeStart = 0L
    private var vibrating = false
    private var alarm: Alarm? = null
    private var settings = AppSettings()
    private var mode = Mode.SILENT
    private var earDevice: AudioDeviceInfo? = null
    private var savedVolume = -1
    private var wakeLock: PowerManager.WakeLock? = null
    private var listening = false

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            // 이어폰이 빠지는 순간(스피커로 소리가 새기 직전) 시스템이 보내는 신호
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) onEarphoneLost()
        }
    }

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            onDevicesChanged()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            onDevicesChanged()
        }
    }

    private val fadeRunnable = object : Runnable {
        override fun run() {
            val p = player ?: return
            val total = (alarm?.fadeSeconds ?: 0) * 1000L
            val frac = if (total <= 0) 1f
            else ((SystemClock.elapsedRealtime() - fadeStart).toFloat() / total).coerceIn(0f, 1f)
            val v = playerMax * (0.05f + 0.95f * frac)
            try {
                p.setVolume(v, v)
            } catch (_: Exception) {
            }
            if (frac < 1f) handler.postDelayed(this, 250)
        }
    }

    private val autoStopRunnable = Runnable { stopRinging(false) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(AudioManager::class.java)
        Notifications.ensureChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent.getIntExtra(EXTRA_ID, -1))
            ACTION_SNOOZE -> snooze()
            ACTION_DISMISS -> stopRinging(false)
            else -> if (alarm == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    // ───────────────────────── 울림 시작 ─────────────────────────

    private fun start(id: Int) {
        // 포그라운드 시작은 가장 먼저 (안 하면 시스템이 앱을 종료함)
        startForegroundCompat(buildNotification("알람", "준비 중…", false))

        val a = AlarmStore.get(this, id)
        if (a == null) {
            stopRinging(false)
            return
        }
        if (alarm != null) releaseAudio() // 이미 다른 알람이 울리던 중이면 정리

        alarm = a
        settings = AlarmStore.loadSettings(this)
        acquireWakeLock()

        val ear = Earphones.find(this, settings.includeBluetooth)
        if (ear != null) playOnEarphone(ear) else applyFallback()
        if (a.vibrate) startVibration()

        if (!listening) {
            ContextCompat.registerReceiver(
                this, noisyReceiver,
                IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
                ContextCompat.RECEIVER_EXPORTED,
            )
            audio.registerAudioDeviceCallback(deviceCallback, handler)
            listening = true
        }

        handler.removeCallbacks(autoStopRunnable)
        handler.postDelayed(autoStopRunnable, settings.autoStopMinutes * 60_000L)
        publishState()
    }

    private fun playOnEarphone(ear: AudioDeviceInfo) {
        stopPlayer()
        val a = alarm ?: return
        if (settings.forceVolume) applyVolume(a.volume)
        val p = Sounds.createPlayer(this, a.soundUri, ear)
        if (p == null) {
            restoreVolume()
            applyFallback()
            return
        }
        earDevice = ear
        mode = Mode.EARPHONE
        playerMax = if (settings.forceVolume) 1f else a.volume / 100f
        startPlayer(p)
    }

    private fun playOnSpeaker() {
        stopPlayer()
        val a = alarm ?: return
        val p = Sounds.createPlayer(this, a.soundUri, null)
        if (p == null) {
            mode = Mode.VIBRATE
            startVibration()
            return
        }
        mode = Mode.SPEAKER
        playerMax = (a.volume / 100f).coerceIn(0.05f, 1f)
        startPlayer(p)
    }

    private fun startPlayer(p: MediaPlayer) {
        val fade = (alarm?.fadeSeconds ?: 0) > 0
        val v = if (fade) playerMax * 0.05f else playerMax
        try {
            p.setVolume(v, v)
            p.start()
        } catch (e: Exception) {
            p.release()
            return
        }
        player = p
        if (fade) {
            fadeStart = SystemClock.elapsedRealtime()
            handler.removeCallbacks(fadeRunnable)
            handler.post(fadeRunnable)
        }
    }

    private fun applyFallback() {
        stopPlayer()
        earDevice = null
        when (settings.fallback) {
            Fallback.SPEAKER -> playOnSpeaker()
            Fallback.VIBRATE -> {
                mode = Mode.VIBRATE
                startVibration()
            }
            Fallback.SILENT -> mode = Mode.SILENT
        }
    }

    // ───────────────────────── 이어폰 연결 변화 ─────────────────────────

    private fun onEarphoneLost() {
        val a = alarm ?: return
        if (mode != Mode.EARPHONE) return
        stopPlayer() // 스피커로 새기 전에 즉시 정지
        restoreVolume()
        applyFallback()
        if (a.vibrate) startVibration()
        publishState()
    }

    private fun onDevicesChanged() {
        val a = alarm ?: return
        val ear = Earphones.find(this, settings.includeBluetooth)
        if (mode == Mode.EARPHONE) {
            when {
                ear == null -> onEarphoneLost()
                ear.id != earDevice?.id -> { // 다른 이어폰으로 바뀜
                    playOnEarphone(ear)
                    publishState()
                }
            }
        } else if (ear != null && settings.resumeOnReconnect) {
            stopPlayer()
            if (!a.vibrate) stopVibration()
            playOnEarphone(ear)
            publishState()
        }
    }

    // ───────────────────────── 스누즈 / 끄기 ─────────────────────────

    private fun snooze() {
        val a = alarm
        if (a != null) {
            val fresh = AlarmStore.get(this, a.id)
            if (fresh != null) {
                val until = System.currentTimeMillis() + settings.snoozeMinutes * 60_000L
                val updated = fresh.copy(snoozeUntil = until)
                AlarmStore.upsert(this, updated)
                AlarmScheduler.schedule(this, updated)
                Toast.makeText(
                    this, "${settings.snoozeMinutes}분 뒤(${TimeUtil.formatClock(until)})에 다시 울려요",
                    Toast.LENGTH_LONG,
                ).show()
            }
        }
        stopRinging(true)
    }

    private fun stopRinging(snoozed: Boolean) {
        val a = alarm
        if (a != null && a.temporary && !snoozed) {
            AlarmScheduler.cancel(this, a.id)
            AlarmStore.delete(this, a.id)
        }
        cleanup()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        releaseAudio()
        if (listening) {
            try {
                unregisterReceiver(noisyReceiver)
            } catch (_: Exception) {
            }
            audio.unregisterAudioDeviceCallback(deviceCallback)
            listening = false
        }
        alarm = null
        ringing.value = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun releaseAudio() {
        handler.removeCallbacks(fadeRunnable)
        stopPlayer()
        stopVibration()
        restoreVolume()
        earDevice = null
    }

    private fun stopPlayer() {
        handler.removeCallbacks(fadeRunnable)
        player?.let {
            try {
                it.setVolume(0f, 0f)
                if (it.isPlaying) it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        player = null
    }

    // ───────────────────────── 볼륨 / 진동 ─────────────────────────

    /** 이어폰 미디어 볼륨을 알람 볼륨으로 맞춤 (끝나면 원래대로 복구) */
    private fun applyVolume(percent: Int) {
        try {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (savedVolume < 0) savedVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            val target = (max * percent / 100f).roundToInt().coerceIn(1, max)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        } catch (_: Exception) {
        }
    }

    private fun restoreVolume() {
        if (savedVolume >= 0) {
            try {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, savedVolume, 0)
            } catch (_: Exception) {
            }
            savedVolume = -1
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrator(): Vibrator =
        if (Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java).defaultVibrator
        else getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    @Suppress("DEPRECATION")
    private fun startVibration() {
        if (vibrating) return
        try {
            val effect = VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0)
            vibrator().vibrate(
                effect,
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build(),
            )
            vibrating = true
        } catch (_: Exception) {
        }
    }

    private fun stopVibration() {
        if (!vibrating) return
        try {
            vibrator().cancel()
        } catch (_: Exception) {
        }
        vibrating = false
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "EarAlarm:ring").apply {
            acquire((settings.autoStopMinutes + 2) * 60_000L)
        }
    }

    // ───────────────────────── 알림 / 상태 ─────────────────────────

    private fun modeText(): String = when (mode) {
        Mode.EARPHONE -> "🎧 이어폰으로만 재생 중" +
            (earDevice?.let { " (${Earphones.describe(it)})" } ?: "")
        Mode.SPEAKER -> "🔊 이어폰이 없어서 스피커로 재생 중"
        Mode.VIBRATE -> "📳 이어폰이 없어서 진동으로 알려요"
        Mode.SILENT -> "🔕 이어폰이 없어서 소리 없이 표시만 해요"
    }

    private fun publishState() {
        val a = alarm ?: return
        val text = modeText()
        ringing.value = RingInfo(a.id, a.label, text, a.mission, settings.snoozeMinutes)
        val title = a.label.ifBlank { "알람" } + " · " + TimeUtil.formatTime(a.hour, a.minute)
        try {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIF_ID, buildNotification(title, text, true))
        } catch (_: Exception) {
        }
    }

    private fun startForegroundCompat(n: Notification) {
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun servicePi(action: String, code: Int): PendingIntent = PendingIntent.getService(
        this, code, actionIntent(this, action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun buildNotification(title: String, text: String, withActions: Boolean): Notification {
        val ringIntent = Intent(this, RingActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
        val ringPi = PendingIntent.getActivity(
            this, 10, ringIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = NotificationCompat.Builder(this, Notifications.CHANNEL_RING)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(ringPi)
            .setFullScreenIntent(ringPi, true) // 잠금화면에서 알람 화면 띄우기
        if (withActions) {
            b.addAction(0, "💤 ${settings.snoozeMinutes}분 뒤", servicePi(ACTION_SNOOZE, 11))
            if (alarm?.mission != true) b.addAction(0, "끄기", servicePi(ACTION_DISMISS, 12))
        }
        return b.build()
    }
}
